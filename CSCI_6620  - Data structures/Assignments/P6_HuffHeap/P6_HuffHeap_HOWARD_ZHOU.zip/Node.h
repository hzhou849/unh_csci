#pragma once
class Node
{
public:
	Node() {}
	~Node() {}

	char ch;
	int tally;
	Node *left;
	Node *right;
};

