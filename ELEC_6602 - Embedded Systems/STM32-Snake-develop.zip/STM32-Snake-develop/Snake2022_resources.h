//typedef enum
//{
//    NO_CHANGE,
//    UP,
//    DOWN,
//    LEFT,
//    RIGHT
//} Direction;

