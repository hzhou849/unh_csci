#include "Snake2022_objects.h"
#include "Snake2022_resources.h"

//--------------------- User code ---------------------//

//----------------- End of User code ------------------//

// Event Handlers